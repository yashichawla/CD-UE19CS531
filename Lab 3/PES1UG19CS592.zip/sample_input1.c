int main()
{
	int a = 2;
	// a = a + "1";
	a = "3"+7;
	a = 56;
	a=8+"23";
	a=a+1;
	int b = 2 * 3;
}
