int main()
{
int a=5+2;
a=7*14;
float b=4.6+3455645.7;
double c=6.9845;
char d="c";
}
