int main()
{
	int a;
	float b;
	double c;
	char d;
}
